
-- Add 'google' to the list of supported AI providers
ALTER TYPE public.ai_provider ADD VALUE 'google';
